This is the README file.
It is used for Exercises in Node.js assignment.
